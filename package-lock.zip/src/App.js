import logo from './logo.svg';
import './App.css';
import Immigration from './Immigration';

function App() {
  return (
    <div className="App">
      <Immigration />
    </div>
  );
}

export default App;
