import React,{useState} from "react";
const CheckList = () =>{

    const [checkAdd, getCheckAdd] = useState (false);

     const PreferAdd = (event) => {
          getCheckAdd(event.target.checked)
     }

    return (
      <div>
        <form class="bg">
            <div class="form-group mt-20 d-flex">
               <div class="label">
                    <label> Name:</label>
                </div>
                <div>
                   <input class="form-control" type="text" placeholder="First Name" name="fistname" />
                   <input class="form-control" type="text" placeholder="Middle Name" name="middlename" />
                   <input class="form-control" type="text" placeholder="Last Name" name="lastname" />
                </div>
            </div>

            <div class="form-group mt-20 d-flex">
               <div class="label">
                    <label> DATE OF BIRTH:</label>
                </div>
                <div>
                   <input class="form-control" type="text" placeholder="Month" name="month" />
                   <input class="form-control" type="text" placeholder="Date" name="date" />
                   <input class="form-control" type="text" placeholder="Year" name="year" />
                </div>
            </div>

            <div class="form-group mt-20 d-flex">
               <div class="label">
                    <label> PLACE OF BIRTH:</label>
                </div>
                <div>
                <input class="form-control" type="text" placeholder="city" />
                           <input class="form-control" type="text" placeholder="state" />
                           <input class="form-control" type="text" placeholder="pin" />
                </div>
            </div>

            <div class="form-group mt-20 d-flex">
                <div  class="label" >
                    <label> ADDRESS</label>
                </div>
                <div>
                    <textarea class="form-control"></textarea>
                </div>
            </div>

            <div class="form-group mt-20 d-flex">
                <div  class="label" >
                    <label> PERMANENT ADDRESS IN FOREIGN COUNTRY </label>
                </div>
                <div>
                    <textarea class="form-control"></textarea>
                </div>
            </div>

          
            
            <br/><button class="btn btn-primary">Save</button>
        </form>
        </div>

        
    )
};


export default CheckList;