import React,{useState} from "react";
const PermInfo = () =>{

    const [checkAdd, getCheckAdd] = useState (false);

     const PreferAdd = (event) => {
          getCheckAdd(event.target.checked)
     }

    return (
      <div>
        <form class="bg">
            <div class="form-group mt-20 d-flex">
               <div class="label">
                    <label> FullName:</label>
                </div>
                <div>
                   <input class="form-control" type="text" placeholder="fullname" name="name" / >
                </div>
            </div>

            <div class="form-group mt-20 d-flex">
                <div  class="label" >
                    <label> Current Home address:</label>
                </div>
                <div>
                    <textarea class="form-control"></textarea>
                </div>
            </div>

            <div class="form-group mt-20 d-flex">
                <div class="label">
                    <label>Total Years of Experance:</label>
                </div>
                <div>
                   <input class="form-control" type="number" placeholder="year:months" required/>
                </div>
            </div>

            <div class="form-group mt-20 d-flex" >
               <div class="label">
                    <label> Current Location:</label>
                </div>
                <div class="dec">
                           <input class="form-control" type="text" placeholder="city" />
                           <input class="form-control" type="text" placeholder="state" />
                           <input class="form-control" type="text" placeholder="pin" />
                </div>
            </div>

            <div class="form-group mt-20 d-flex" >
               <div class="label">
                    <label>Availability(How soon can you join</label>
                </div> 
                <div>
                <input class="form-control" type="text" placeholder="Availability" />
                </div>  
            </div>

            <div class="form-group mt-20 d-flex" >
               <div class="label">
                    <label>Interested in Relocation?</label>
                </div> 
                <div class="form-check">
                    <input class="form-check-input" type="radio" name="relocation" id="exampleRadios1" value="yes" checked />
                    <label class="form-check-label" for="exampleRadios1">
                        Yes
                    </label>
                </div>
                <div class="form-check">
                    <input class="form-check-input" type="radio" name="relocation" id="exampleRadios2" value="female" />
                    <label class="form-check-label" for="exampleRadios2">
                        No
                    </label>
                </div> 
            </div> 

            <div class="form-group mt-20 d-flex">
               <div class="label">
                    <label>prefared location:-</label><input type="checkbox"  onClick = {(event) => PreferAdd(event)}></input>
                </div>
                {checkAdd  &&
                 <div class="dec">
                           <input class="form-control" type="text" placeholder="city" />
                           <input class="form-control" type="text" placeholder="state" />
                           <inputc type="text" placeholder="pin" />
                        </div>
                }
             </div>

           

            <div class="form-group mt-20 d-flex">
                <div class="label" >
                    <label class="label"> SSN:- </label>
                </div>
                <div>
                   <input class="form-control" type="text" placeholder="156*****" />
                </div>
            </div>
            <div class="form-group mt-20 d-flex">
                <div  class="label" >
                    <label> Education details</label>
                </div>
                <div>
                    <textarea class="form-control"></textarea>
                </div>
            </div>
            <div class="form-group mt-20 d-flex">
                <div  class="label">
                    <label>  phone no</label>
                </div>
                <div>
                    <input class="form-control" type="number" required/>
                </div>
            </div>
            <div class="form-group mt-20 d-flex" >
               <div class="label">
                     <label> Marital Status</label>
                </div>
                <div>
                    <select class="form-control">
                        <option>Select</option>
                        <option>Un married</option>
                        <option> married</option>
                        <option>single</option>
                    </select>
                </div>
            </div>
            <div class="form-group mt-20 d-flex">
               <div class="label">
                    <label> salary</label>
                </div>
                <div>
               <input class="form-control" type="number"/>
                </div>
            </div>
            <div class="form-group mt-20 d-flex">
               <div class="label">
                    <label>Expected salary </label>
                </div>
                <div>
                   <input class="form-control" type="number"/>
                </div>
            </div>
            
            <br/><button class="btn btn-primary">Save</button>
        </form>
        </div>

        
    )
};


export default PermInfo;