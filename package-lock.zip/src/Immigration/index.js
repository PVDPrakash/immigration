import React from "react";
import ReactDOM from "react-dom";
import ReactWizard from "react-bootstrap-wizard";
import { Container, Row, Col } from "reactstrap";

import "bootstrap/dist/css/bootstrap.css";
import PersonalInfo from "./PersonalInfo";
import CheckList from "./CheckList";
import PermInfo from "./PermInfo";

class FirstStep extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      firstStep: "Personal Information"
    };
  }
  render() {
    return <div>
      <PersonalInfo />
    </div>;
  }
}
class SecondStep extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      secondStep: "second step here"
    };
  }
  isValidated() {
    // do some validations
    // decide if you will
    return true;
    // or you will
    // return false;
  }
  render() {
    return <div><CheckList /></div>;
  }
}
class ThirdStep extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      thirdStep: "third step here"
    };
  }
  render() {
    return <div><PermInfo /></div>;
  }
}

var steps = [
  // this step hasn't got a isValidated() function, so it will be considered to be true
  { stepName: "Personal Information", component: FirstStep },
  // this step will be validated to false
  { stepName: "H1B CHECK LIST", component: SecondStep },
  // this step will never be reachable because of the seconds isValidated() steps function that will always return false
  { stepName: "Perm WorkSheet", component: ThirdStep }
];

class Immigration extends React.Component {
  finishButtonClick(allStates) {
    console.log(allStates);
  }
  render() {
    return (
      <Container fluid style={{ marginTop: "15px" }}>
        <Row>
          <Col xs={10}  className="m-auto">
            <ReactWizard
              steps={steps}
              navSteps
              title="Immigration Process"
              description="Kindly share a copy of DL, updated Resume and Visa Along with the below required details."
              headerTextCenter
              validate
              color="primary"
              finishButtonClick={this.finishButtonClick}
            />
          </Col>
        </Row>
      </Container>
    );
  }
}


export default Immigration;